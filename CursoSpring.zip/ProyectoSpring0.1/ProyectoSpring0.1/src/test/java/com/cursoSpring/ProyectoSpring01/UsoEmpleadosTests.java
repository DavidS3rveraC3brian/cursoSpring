package com.cursoSpring.ProyectoSpring01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsoEmpleadosTests {

	@Test
	void contextLoads() {
	}

}
