package com.cursoSpring.ProyectoSpring01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class UsoEmpleados {

	public static void main(String[] args) {
		SpringApplication.run(UsoEmpleados.class, args);
		/*
		//creacion de objetos tipo Empleado
		
		Empleados Empleado1=new DirectorEmpleado();
		
		//uso de objetos creados
		
		System.out.println(Empleado1.getTareas());*/
		
		ClassPathXmlApplicationContext contexto=new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empleados Juan=contexto.getBean("miEmpleado", Empleados.class);
		
		System.out.println(Juan.getTareas());
		
		
		contexto.close();
	}

}
