package com.cursoSpring.ProyectoSpring01;

public class DirectorEmpleado implements Empleados {


	
	@Override
	public String getTareas() {
		// TODO Auto-generated method stub
		return "Gestionar la plantilla de la empresa";
	}


}
