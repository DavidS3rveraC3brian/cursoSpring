package com.cursoSpring.ProyectoSpring01;

public interface CreacionInformes {
	
	public String getInforme();

}
