package com.cursoSpring.ProyectoSpring01;

public class JefeEmpleado implements Empleados{

	public String getTareas() {
		
		return "Gestiono las cuestiones relativas a mis empleados de sección";
	}

}
