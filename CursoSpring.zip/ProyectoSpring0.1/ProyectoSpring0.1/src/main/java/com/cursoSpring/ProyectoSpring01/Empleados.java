package com.cursoSpring.ProyectoSpring01;

public interface Empleados {

	public String getTareas(); 
	
	public String getInforme();
}
